
Este repositorio contiene diferentes trabajos individuales de la materia Arquitectura de software.

## Contenido

- **Tutorial_001**: pequeña aplicación de consola en Java (sin frameworks) que permita solicitar al usuario un nombre por pantalla, y guardarlo en un archivo de texto txt.
